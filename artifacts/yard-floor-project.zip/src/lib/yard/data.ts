import type { CSSProperties } from "react";

export const STORAGE_KEY = "yard-floor-v1";
export const MAX_SLOTS = 12;
export const MAX_HEIGHT = 12;

export const PRODUCTS = [
  { id: "awp", name: "AWP" },
  { id: "peas", name: "Peas" },
  { id: "keystone", name: "Keystone" },
  { id: "compass", name: "Compass" },
  { id: "garb", name: "Garb" },
  { id: "passion", name: "Passion" },
  { id: "icicle", name: "Icicle" },
  { id: "barley", name: "Barley" },
  { id: "mixed", name: "Mixed" },
  { id: "other", name: "Other" },
] as const;

export type ProductId = (typeof PRODUCTS)[number]["id"];
export type StackKind = "tote" | "box" | "pill";
export type Zone = "west" | "east" | "lane" | "treater";
export type FilterId = "all" | "unknown" | ProductId;

export type Layer = {
  label: string;
  product: ProductId;
  height: number;
  unknown: boolean;
};

export type Stack = {
  id: string;
  kind: StackKind;
  layers: Layer[];
  note: string;
};

export type Bay = {
  id: string;
  zone: Zone;
  code: string;
  title: string;
  detail?: string;
  rail: ProductId | "neutral";
  railRight?: ProductId;
  slots: (Stack | null)[];
};

const PRODUCT_SET = new Set<string>(PRODUCTS.map((p) => p.id));
const KIND_SET = new Set<string>(["tote", "box", "pill"]);
const ZONE_SET = new Set<string>(["west", "east", "lane", "treater"]);

export function isProduct(value: string): value is ProductId {
  return PRODUCT_SET.has(value);
}

export function productName(id: ProductId): string {
  return PRODUCTS.find((p) => p.id === id)?.name ?? id;
}

export function zoneName(zone: Zone): string {
  if (zone === "west") return "Totes aisle";
  if (zone === "east") return "Numbered aisle";
  if (zone === "lane") return "Forklift lane";
  return "Seed treater";
}

export function kindName(kind: StackKind): string {
  if (kind === "tote") return "Tote";
  if (kind === "box") return "Boxes";
  return "Split stack";
}

export function stackLabel(stack: Stack): string {
  const text = stack.layers.map((layer) => layer.label.trim() || "Untitled").join(" / ");
  return text || "Untitled";
}

export function markColor(layer: Layer): string {
  if (layer.unknown) return "var(--color-swatch-mixed)";
  return `var(--color-swatch-${layer.product})`;
}

export function markStyle(layer: Layer): CSSProperties {
  if (layer.unknown) {
    return { "--mark": "var(--color-swatch-mixed)", "--mark-fg": "var(--color-muted)" } as CSSProperties;
  }
  return {
    "--mark": `var(--color-swatch-${layer.product})`,
    "--mark-fg": `var(--color-swatch-${layer.product}-fg)`,
  } as CSSProperties;
}

export function railColor(rail: ProductId | "neutral"): string {
  if (rail === "neutral") return "var(--color-line-strong)";
  return `var(--color-swatch-${rail})`;
}

function clampHeight(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) return 1;
  return Math.min(MAX_HEIGHT, Math.max(1, Math.round(n)));
}

function cleanLayer(value: unknown, fallback: Layer): Layer {
  const raw = (value ?? {}) as Partial<Layer>;
  const product = typeof raw.product === "string" && isProduct(raw.product) ? raw.product : fallback.product;
  return {
    label: typeof raw.label === "string" ? raw.label.slice(0, 48) : fallback.label,
    product,
    height: clampHeight(raw.height ?? fallback.height),
    unknown: Boolean(raw.unknown),
  };
}

export function normalizeStack(stack: Stack): Stack {
  const kind: StackKind = KIND_SET.has(stack.kind) ? stack.kind : "box";
  const base = stack.layers[0] ?? {
    label: "Untitled",
    product: "other" as ProductId,
    height: 1,
    unknown: false,
  };
  const layers = [cleanLayer(stack.layers[0], base)];
  if (kind === "pill") {
    layers.push(
      cleanLayer(stack.layers[1], {
        label: "Second item",
        product: layers[0].product,
        height: 1,
        unknown: false,
      }),
    );
  }
  return {
    id: stack.id,
    kind,
    layers,
    note: typeof stack.note === "string" ? stack.note.slice(0, 240) : "",
  };
}

export function createStack(partial?: Partial<Stack>): Stack {
  return normalizeStack({
    id: crypto.randomUUID(),
    kind: partial?.kind ?? "tote",
    note: partial?.note ?? "",
    layers: partial?.layers ?? [
      { label: "New stack", product: "other", height: 1, unknown: false },
    ],
  });
}

function cells(stacks: Stack[], count?: number): (Stack | null)[] {
  const size = Math.max(count ?? 0, stacks.length, 5);
  const slots: (Stack | null)[] = Array.from({ length: size }, () => null);
  stacks.forEach((stack, index) => {
    slots[index] = stack;
  });
  return slots;
}

function layer(label: string, product: ProductId, height: number, unknown = false): Layer {
  return { label, product, height, unknown };
}

function tote(id: string, label: string, product: ProductId, height: number, unknown = false): Stack {
  return { id, kind: "tote", note: "", layers: [layer(label, product, height, unknown)] };
}

function box(id: string, label: string, product: ProductId, height: number, unknown = false): Stack {
  return { id, kind: "box", note: "", layers: [layer(label, product, height, unknown)] };
}

function pill(id: string, a: Layer, b: Layer): Stack {
  return { id, kind: "pill", note: "", layers: [a, b] };
}

function bay(
  partial: Omit<Bay, "slots"> & { stacks: Stack[]; count?: number },
): Bay {
  const { stacks, count, ...rest } = partial;
  return { ...rest, slots: cells(stacks, count) };
}

export function createSurvey(): Bay[] {
  return [
    bay({
      id: "w1",
      zone: "west",
      code: "1",
      title: "Totes — AWP",
      rail: "awp",
      stacks: [tote("w1a", "AWP", "awp", 3), tote("w1b", "AWP", "awp", 2)],
    }),
    bay({
      id: "w2",
      zone: "west",
      code: "2",
      title: "AWP treated",
      rail: "awp",
      stacks: [
        box("w2a", "AWP treated", "awp", 4),
        box("w2b", "AWP treated", "awp", 4),
        box("w2c", "AWP treated", "awp", 4),
        box("w2d", "AWP treated", "awp", 4),
      ],
    }),
    bay({
      id: "w3",
      zone: "west",
      code: "3",
      title: "Frontier peas",
      rail: "peas",
      stacks: [tote("w3a", "Frontier peas", "peas", 2), tote("w3b", "Frontier peas", "peas", 2)],
    }),
    bay({
      id: "w4",
      zone: "west",
      code: "4",
      title: "Frontier peas",
      rail: "peas",
      stacks: [
        tote("w4a", "Frontier peas", "peas", 2),
        tote("w4b", "Frontier peas", "peas", 2),
        tote("w4c", "Frontier peas", "peas", 2),
      ],
    }),
    bay({
      id: "w5",
      zone: "west",
      code: "5",
      title: "Frontier peas",
      rail: "peas",
      stacks: [
        tote("w5a", "Frontier peas", "peas", 2),
        tote("w5b", "Frontier peas", "peas", 2),
        tote("w5c", "Frontier peas", "peas", 2),
      ],
    }),
    bay({
      id: "w6",
      zone: "west",
      code: "6",
      title: "Row 6 mix",
      detail:
        "1 tote black barley · split boxes: 2 RedCoat + 2 Compass treated · three box stacks unknown.",
      rail: "mixed",
      stacks: [
        box("w6a", "Unknown", "mixed", 4, true),
        box("w6b", "Unknown", "mixed", 4, true),
        box("w6c", "Unknown", "mixed", 4, true),
        pill("w6d", layer("RedCoat", "passion", 2), layer("Compass treated", "compass", 2)),
        tote("w6e", "Black barley", "barley", 1),
      ],
    }),
    bay({
      id: "w7",
      zone: "west",
      code: "7",
      title: "Mixed stack",
      detail:
        "Rotated stock. Survey note: (2 Keystone, 1 RedCliff) · (2 SWW/blk mix, 1 blk bly) · (2 hulless bly, 2 blk bly) · (4 blk barley) · (2 McGuire seed, 2 unknown). Paired to the drawn shapes — edit a label if a pair is off.",
      rail: "mixed",
      stacks: [
        pill("w7a", layer("Hulless barley", "barley", 2), layer("Black barley", "barley", 2)),
        box("w7b", "Black barley", "barley", 4),
        pill(
          "w7c",
          layer("McGuire seed", "other", 2),
          layer("Unknown", "mixed", 2, true),
        ),
        pill("w7d", layer("Keystone", "keystone", 2), layer("RedCliff", "passion", 1)),
        pill("w7e", layer("SWW / black mix", "mixed", 2), layer("Black barley", "barley", 1)),
      ],
    }),
    bay({
      id: "treater",
      zone: "treater",
      code: "ST",
      title: "Seed treater",
      detail: "Cardboard ½–¾ stack · 2× full wood bundle.",
      rail: "neutral",
      stacks: [
        { ...box("tr1", "Cardboard", "other", 1), note: "½–¾ stack" },
        { ...box("tr2", "Wood bundle", "other", 1), note: "Full bundle" },
        { ...box("tr3", "Wood bundle", "other", 1), note: "Full bundle" },
      ],
    }),
    bay({
      id: "lane",
      zone: "lane",
      code: "FL",
      title: "Forklift lane",
      detail: "Hold a stack here while you clear a cell.",
      rail: "neutral",
      count: 4,
      stacks: [],
    }),
    bay({
      id: "e7",
      zone: "east",
      code: "7",
      title: "AWP untreated",
      rail: "awp",
      stacks: [
        box("e7a", "AWP untreated", "awp", 3),
        box("e7b", "AWP untreated", "awp", 4),
        box("e7c", "AWP untreated", "awp", 4),
        box("e7d", "AWP untreated", "awp", 4),
      ],
    }),
    bay({
      id: "e8",
      zone: "east",
      code: "8",
      title: "Keystone treated",
      rail: "keystone",
      stacks: [
        box("e8a", "Keystone treated", "keystone", 5),
        box("e8b", "Keystone treated", "keystone", 5),
        box("e8c", "Keystone treated", "keystone", 4),
        box("e8d", "Keystone treated", "keystone", 4),
      ],
    }),
    bay({
      id: "e9",
      zone: "east",
      code: "9",
      title: "Frontier garb",
      rail: "garb",
      stacks: [
        tote("e9a", "Frontier garb", "garb", 1),
        tote("e9b", "Frontier garb", "garb", 2),
        tote("e9c", "Frontier garb", "garb", 2),
        tote("e9d", "Frontier garb", "garb", 2),
      ],
    }),
    bay({
      id: "e10",
      zone: "east",
      code: "10",
      title: "Icicle winter peas / Compass",
      rail: "icicle",
      railRight: "compass",
      stacks: [
        box("e10a", "Icicle winter peas", "icicle", 3),
        tote("e10b", "Compass", "compass", 2),
        tote("e10c", "Compass", "compass", 2),
      ],
    }),
    bay({
      id: "e11",
      zone: "east",
      code: "11",
      title: "Keystone",
      rail: "keystone",
      stacks: [
        tote("e11a", "Keystone", "keystone", 1),
        tote("e11b", "Keystone", "keystone", 2),
        tote("e11c", "Keystone", "keystone", 2),
        tote("e11d", "Keystone", "keystone", 2),
      ],
    }),
    bay({
      id: "e12",
      zone: "east",
      code: "12",
      title: "Keystone",
      rail: "keystone",
      stacks: [
        tote("e12a", "Keystone", "keystone", 2),
        tote("e12b", "Keystone", "keystone", 2),
        tote("e12c", "Keystone", "keystone", 2),
        tote("e12d", "Keystone", "keystone", 2),
      ],
    }),
    bay({
      id: "e13",
      zone: "east",
      code: "13",
      title: "Uncert / Compass",
      detail: "Marked uncertain on the survey, colored as Compass.",
      rail: "compass",
      stacks: [
        tote("e13a", "Compass", "compass", 2),
        tote("e13b", "Compass", "compass", 2),
        tote("e13c", "Compass", "compass", 2),
        tote("e13d", "Compass", "compass", 2),
      ],
    }),
    bay({
      id: "e14",
      zone: "east",
      code: "14",
      title: "Keystone treated / Passion",
      rail: "keystone",
      railRight: "passion",
      stacks: [
        box("e14a", "Keystone treated", "keystone", 3),
        box("e14b", "Passion", "passion", 3),
        box("e14c", "Passion", "passion", 4),
        box("e14d", "Passion", "passion", 4),
      ],
    }),
    bay({
      id: "e15",
      zone: "east",
      code: "15",
      title: "Garb screens",
      rail: "garb",
      stacks: [
        tote("e15a", "Garb screens", "garb", 1),
        tote("e15b", "Garb screens", "garb", 2),
        tote("e15c", "Garb screens", "garb", 2),
        tote("e15d", "Garb screens", "garb", 2),
      ],
    }),
    bay({
      id: "e16",
      zone: "east",
      code: "16",
      title: "Keystone",
      rail: "keystone",
      stacks: [
        tote("e16a", "Keystone", "keystone", 2),
        tote("e16b", "Keystone", "keystone", 2),
        tote("e16c", "Keystone", "keystone", 2),
        tote("e16d", "Keystone", "keystone", 2),
      ],
    }),
    bay({
      id: "e17",
      zone: "east",
      code: "17",
      title: "Keystone",
      rail: "keystone",
      stacks: [
        tote("e17a", "Keystone", "keystone", 2),
        tote("e17b", "Keystone", "keystone", 2),
        tote("e17c", "Keystone", "keystone", 2),
        tote("e17d", "Keystone", "keystone", 2),
      ],
    }),
    bay({
      id: "e18",
      zone: "east",
      code: "18",
      title: "Keystone",
      rail: "keystone",
      stacks: [
        tote("e18a", "Keystone", "keystone", 2),
        tote("e18b", "Keystone", "keystone", 2),
        tote("e18c", "Keystone", "keystone", 2),
      ],
    }),
    bay({
      id: "e19",
      zone: "east",
      code: "19",
      title: "Scale",
      detail: "Scale station. Empty on the survey.",
      rail: "neutral",
      count: 4,
      stacks: [],
    }),
  ];
}

export type StackHit = { bay: Bay; index: number; stack: Stack };

export function findStack(bays: Bay[], id: string): StackHit | null {
  for (const bay of bays) {
    const index = bay.slots.findIndex((slot) => slot?.id === id);
    const stack = bay.slots[index];
    if (stack) return { bay, index, stack };
  }
  return null;
}

export function tally(bays: Bay[]) {
  let stacks = 0;
  let units = 0;
  const by = new Map<string, number>();
  for (const bay of bays) {
    for (const slot of bay.slots) {
      if (!slot) continue;
      stacks += 1;
      for (const layer of slot.layers) {
        units += layer.height;
        const key = layer.unknown ? "unknown" : layer.product;
        by.set(key, (by.get(key) ?? 0) + layer.height);
      }
    }
  }
  return { stacks, units, by };
}

export function stackMatches(stack: Stack, bay: Bay, filter: FilterId, query: string): boolean {
  const q = query.trim().toLowerCase();
  const productHit = stack.layers.some((layer) => {
    if (filter === "all") return true;
    if (filter === "unknown") return layer.unknown;
    return !layer.unknown && layer.product === filter;
  });
  if (!productHit) return false;
  if (!q) return true;
  const blob = [
    bay.title,
    bay.detail ?? "",
    bay.code,
    zoneName(bay.zone),
    stack.note,
    ...stack.layers.flatMap((layer) => [layer.label, productName(layer.product), kindName(stack.kind)]),
  ]
    .join(" ")
    .toLowerCase();
  return blob.includes(q);
}

function clone(bays: Bay[]): Bay[] {
  return structuredClone(bays);
}

export function mapStack(bays: Bay[], id: string, recipe: (stack: Stack) => Stack): Bay[] {
  return bays.map((bay) => ({
    ...bay,
    slots: bay.slots.map((slot) => (slot && slot.id === id ? normalizeStack(recipe(slot)) : slot)),
  }));
}

export function mapBay(bays: Bay[], id: string, recipe: (bay: Bay) => Bay): Bay[] {
  return bays.map((bay) => (bay.id === id ? recipe(bay) : bay));
}

export function moveInGrid(bays: Bay[], stackId: string, toBayId: string, toIndex: number): Bay[] | null {
  const next = clone(bays);
  let fromBay = -1;
  let fromSlot = -1;
  for (let i = 0; i < next.length; i += 1) {
    const slot = next[i].slots.findIndex((entry) => entry?.id === stackId);
    if (slot >= 0) {
      fromBay = i;
      fromSlot = slot;
      break;
    }
  }
  if (fromBay < 0) return null;
  const target = next.find((bay) => bay.id === toBayId);
  if (!target || toIndex < 0 || toIndex >= target.slots.length) return null;
  const source = next[fromBay];
  if (source.id === target.id && fromSlot === toIndex) return null;
  const moving = source.slots[fromSlot];
  const displaced = target.slots[toIndex];
  target.slots[toIndex] = moving;
  source.slots[fromSlot] = displaced;
  return next;
}

export function placeInBay(bays: Bay[], stackId: string, toBayId: string): Bay[] | null {
  const hit = findStack(bays, stackId);
  if (!hit || hit.bay.id === toBayId) return null;
  const next = clone(bays);
  const source = next.find((bay) => bay.id === hit.bay.id);
  const target = next.find((bay) => bay.id === toBayId);
  if (!source || !target) return null;
  const stack = source.slots[hit.index];
  source.slots[hit.index] = null;
  const open = target.slots.findIndex((slot) => slot === null);
  if (open >= 0) {
    target.slots[open] = stack;
    return next;
  }
  if (target.slots.length >= MAX_SLOTS) return null;
  target.slots.push(stack);
  return next;
}

export function removeStack(bays: Bay[], stackId: string): Bay[] {
  return bays.map((bay) => ({
    ...bay,
    slots: bay.slots.map((slot) => (slot?.id === stackId ? null : slot)),
  }));
}

export function addStackToBay(bays: Bay[], bayId: string, stack: Stack): Bay[] | null {
  const next = clone(bays);
  const target = next.find((bay) => bay.id === bayId);
  if (!target) return null;
  const open = target.slots.findIndex((slot) => slot === null);
  const clean = normalizeStack(stack);
  if (open >= 0) {
    target.slots[open] = clean;
    return next;
  }
  if (target.slots.length >= MAX_SLOTS) return null;
  target.slots.push(clean);
  return next;
}

export function addCell(bays: Bay[], bayId: string): Bay[] | null {
  const next = clone(bays);
  const target = next.find((bay) => bay.id === bayId);
  if (!target || target.slots.length >= MAX_SLOTS) return null;
  target.slots.push(null);
  return next;
}

function alignSlots(slots: (Stack | null)[]): (Stack | null)[] {
  const next = slots.slice(0, MAX_SLOTS);
  while (next.length > 5 && next[next.length - 1] == null) next.pop();
  const size = Math.min(MAX_SLOTS, Math.max(next.length, 5));
  while (next.length < size) next.push(null);
  return next;
}

function cleanBay(value: unknown): Bay | null {
  if (!value || typeof value !== "object") return null;
  const raw = value as Partial<Bay>;
  if (typeof raw.id !== "string" || typeof raw.title !== "string" || !Array.isArray(raw.slots)) {
    return null;
  }
  const zone = typeof raw.zone === "string" && ZONE_SET.has(raw.zone) ? (raw.zone as Zone) : "east";
  const rail =
    raw.rail === "neutral" || (typeof raw.rail === "string" && isProduct(raw.rail)) ? raw.rail : "neutral";
  const railRight =
    typeof raw.railRight === "string" && isProduct(raw.railRight) ? raw.railRight : undefined;
  const slots = alignSlots(
    raw.slots.slice(0, MAX_SLOTS).map((slot) => {
      if (slot == null) return null;
      if (typeof slot !== "object" || typeof (slot as Stack).id !== "string") return null;
      const candidate = slot as Stack;
      return normalizeStack({
        id: candidate.id,
        kind: candidate.kind,
        note: candidate.note ?? "",
        layers: Array.isArray(candidate.layers) ? candidate.layers : [],
      });
    }),
  );
  return {
    id: raw.id,
    zone,
    code: typeof raw.code === "string" ? raw.code.slice(0, 6) : "—",
    title: raw.title.slice(0, 64),
    detail: typeof raw.detail === "string" ? raw.detail.slice(0, 400) : undefined,
    rail,
    railRight,
    slots,
  };
}

export function sanitizeLayout(input: unknown): Bay[] | null {
  if (!input || typeof input !== "object") return null;
  const raw = input as { version?: unknown; bays?: unknown };
  if (raw.version !== 1 || !Array.isArray(raw.bays) || raw.bays.length === 0) return null;
  const bays = raw.bays.map(cleanBay);
  if (bays.some((bay) => bay == null)) return null;
  const ids = new Set<string>();
  for (const bay of bays as Bay[]) {
    if (ids.has(bay.id)) return null;
    ids.add(bay.id);
    const stackIds = new Set<string>();
    for (const slot of bay.slots) {
      if (!slot) continue;
      if (stackIds.has(slot.id)) return null;
      stackIds.add(slot.id);
    }
  }
  return bays as Bay[];
}
